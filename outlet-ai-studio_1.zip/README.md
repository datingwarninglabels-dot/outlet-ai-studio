# Scenecraft

AI video generation app. Enter an idea, get a script, generate a scene, export it.

This is **M0**: project setup, Postgres + Google sign-in, and the Owner
account bootstrap. No AI generation yet — that starts at M1 (idea → script →
one scene → export, a vertical slice).

## Stack

- [Next.js](https://nextjs.org) 16 (App Router) + TypeScript + Tailwind CSS
- [Drizzle ORM](https://orm.drizzle.team) on Postgres
- [Auth.js](https://authjs.dev) (NextAuth v5) with Google OAuth, database sessions

The first person to ever sign in becomes the account **Owner**
(`user.isOwner = true`). There's no invite flow yet — this is a
single-admin setup for now.

## 1. Get a Postgres database

Either of these free tiers works fine:

- **[Supabase](https://supabase.com)** — create a project, then go to
  Project Settings → Database → Connection string (use the "Transaction
  pooler" URI if you're deploying somewhere serverless; the direct
  connection URI is fine for local dev).
- **[Neon](https://neon.tech)** — create a project, then copy the connection
  string from the dashboard. It comes with `?sslmode=require` already.

You just need the resulting connection string, e.g.:

```
postgresql://user:password@host:5432/dbname?sslmode=require
```

## 2. Create a Google OAuth client

1. Go to the [Google Cloud Console](https://console.cloud.google.com/apis/credentials).
2. Create a project (or pick an existing one).
3. Configure the OAuth consent screen if you haven't already (External is
   fine for testing; add yourself as a test user if it's in "Testing" mode).
4. Create Credentials → OAuth client ID → Application type: **Web
   application**.
5. Under **Authorized redirect URIs**, add:
   - `http://localhost:3000/api/auth/callback/google` (local dev)
   - `https://your-deployed-domain.com/api/auth/callback/google` (once deployed)
6. Save, then copy the **Client ID** and **Client secret**.

## 3. Configure environment variables

```bash
cp .env.example .env
```

Fill in:

- `DATABASE_URL` — the connection string from step 1.
- `AUTH_SECRET` — generate with `npx auth secret`, or `openssl rand -base64 33`.
- `AUTH_GOOGLE_ID` / `AUTH_GOOGLE_SECRET` — from step 2.

Use `.env`, not `.env.local` — `drizzle-kit` (used for migrations) only
reads `.env`, and Next.js reads both, so `.env` is the one file that works
for everything here.

## 4. Install dependencies and run migrations

```bash
npm install
npm run db:migrate   # applies drizzle/0000_*.sql to your database
```

If you change `src/db/schema.ts` later, generate a new migration first:

```bash
npm run db:generate  # writes a new drizzle/xxxx_*.sql from the schema diff
npm run db:migrate    # applies it
```

`npm run db:studio` opens Drizzle Studio (a local DB browser) if you want to
poke at the tables directly.

## 5. Run it

```bash
npm run dev
```

Visit `http://localhost:3000` — you'll be redirected to `/signin`. Sign in
with Google. Since your database is empty, you'll become the Owner
automatically, and land on `/dashboard` with an "Owner" badge next to your
name.

## What to verify

- [x] The Owner-bootstrap logic itself: first user promoted, second user not,
      Owner status survives a repeat sign-in. Confirmed against a real local
      Postgres — see `scripts/verify-owner-flow.ts` (run it yourself with
      `DATABASE_URL=... npx tsx scripts/verify-owner-flow.ts`).
- [x] Migrations apply cleanly and the schema matches (checked with a real
      `npm run db:migrate` + `\d "user"` in psql).
- [x] Unauthenticated `/` and `/dashboard` redirect to `/signin`; `/signin`
      renders; `/api/auth/providers` and the sign-in POST correctly kick off
      the real Google OIDC handshake (confirmed with the app actually
      running, up to the point where it needs to reach `accounts.google.com`).
- [ ] **The one thing that still needs you**: a real Google OAuth Client
      ID/Secret and an actual browser round trip through Google's consent
      screen — that needs your own Google Cloud project and can't be done on
      your behalf. Once you've got real credentials in `.env`, sign in once
      and confirm you land on `/dashboard` with the **Owner** badge, then
      sign in with a second Google account and confirm *that one* does not
      get the badge.

Once that last box is checked, we move on to M1: idea → script → one scene → export.

## Project layout

```
src/
  app/
    page.tsx              redirects to /dashboard or /signin based on auth
    signin/page.tsx        Google sign-in button
    dashboard/page.tsx     protected page, shows the signed-in user
    api/auth/[...nextauth]/route.ts   Auth.js route handlers
  auth.ts                  Auth.js config (Google provider, Drizzle adapter,
                            Owner-bootstrap logic)
  db/
    schema.ts              Drizzle schema (Auth.js tables + isOwner)
    index.ts                Drizzle client (node-postgres)
drizzle/                   generated SQL migrations (checked in)
drizzle.config.ts          drizzle-kit config
```
