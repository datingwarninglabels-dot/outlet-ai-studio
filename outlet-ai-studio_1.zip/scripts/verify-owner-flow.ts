/**
 * Integration check for the Owner-bootstrap flow, run against a real
 * Postgres database. Exercises the exact same functions Auth.js calls in
 * production (the Drizzle adapter's `createUser`, and our
 * `maybeBootstrapOwner`) — the only thing not exercised here is the actual
 * Google OAuth HTTP round trip, since that requires real Google credentials
 * and interactive consent.
 *
 * Usage: DATABASE_URL=... npx tsx scripts/verify-owner-flow.ts
 * Not wired into `npm run` — this is a one-off verification script, not a
 * permanent test suite.
 */
import { eq } from "drizzle-orm";
import { DrizzleAdapter } from "@auth/drizzle-adapter";

import { db } from "../src/db";
import { accounts, sessions, users, verificationTokens } from "../src/db/schema";
import { maybeBootstrapOwner } from "../src/lib/owner";

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new Error(`FAIL: ${message}`);
  }
  console.log(`  ok: ${message}`);
}

async function main() {
  // Adapter is not fully implemented per the Adapter interface in this
  // context (no request/response cycle), but createUser/getUser are enough
  // to exercise the bootstrap logic exactly as Auth.js would call it.
  const adapter = DrizzleAdapter(db, {
    usersTable: users,
    accountsTable: accounts,
    sessionsTable: sessions,
    verificationTokensTable: verificationTokens,
  });

  console.log("Resetting table (clean slate for this run)...");
  await db.delete(users);

  console.log("\nStep 1: first-ever sign-in creates a user...");
  const alice = await adapter.createUser!({
    id: "",
    name: "Alice Owner",
    email: "alice@example.com",
    emailVerified: null,
    isOwner: false,
  });
  assert(alice.email === "alice@example.com", "adapter.createUser returned the inserted row");

  console.log("Step 2: Auth.js `createUser` event fires -> maybeBootstrapOwner...");
  const alicePromoted = await maybeBootstrapOwner(alice.id);
  assert(alicePromoted === true, "maybeBootstrapOwner returned true for the first user");

  const [aliceRow] = await db.select().from(users).where(eq(users.id, alice.id));
  assert(aliceRow.isOwner === true, "first user's isOwner flag is true in the database");

  console.log("\nStep 3: a second person signs in for the first time...");
  const bob = await adapter.createUser!({
    id: "",
    name: "Bob Nobody",
    email: "bob@example.com",
    emailVerified: null,
    isOwner: false,
  });
  const bobPromoted = await maybeBootstrapOwner(bob.id);
  assert(bobPromoted === false, "maybeBootstrapOwner returned false for the second user");

  const [bobRow] = await db.select().from(users).where(eq(users.id, bob.id));
  assert(bobRow.isOwner === false, "second user's isOwner flag is false in the database");

  console.log("\nStep 4: Alice signs out and back in (returning user, not a new one)...");
  // On a returning sign-in, Auth.js finds the existing user via
  // getUserByAccount/getUserByEmail and does NOT call createUser again, so
  // the createUser event (and maybeBootstrapOwner) never re-fires. Simulate
  // that lookup and confirm her Owner flag is untouched.
  const aliceAgain = await adapter.getUserByEmail!("alice@example.com");
  assert(aliceAgain?.isOwner === true, "returning Owner still has isOwner=true after 'signing in again'");

  console.log("\nStep 5: session callback shape...");
  // This mirrors exactly what src/auth.ts's `session` callback does with
  // the `user` object the adapter hands it on a database-session lookup.
  const fakeSession = { user: {} as { id: string; isOwner: boolean } };
  fakeSession.user.id = aliceRow.id;
  fakeSession.user.isOwner = aliceRow.isOwner;
  assert(fakeSession.user.isOwner === true, "session.user.isOwner would be true for Alice");

  console.log("\nAll checks passed.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
