import NextAuth from "next-auth";
import type { DefaultSession } from "next-auth";
import Google from "next-auth/providers/google";
import { DrizzleAdapter } from "@auth/drizzle-adapter";

import { db } from "@/db";
import { accounts, sessions, users, verificationTokens } from "@/db/schema";
import { maybeBootstrapOwner } from "@/lib/owner";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      isOwner: boolean;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/adapters" {
  interface AdapterUser {
    isOwner: boolean;
  }
}

export const { handlers, signIn, signOut, auth } = NextAuth({
  adapter: DrizzleAdapter(db, {
    usersTable: users,
    accountsTable: accounts,
    sessionsTable: sessions,
    verificationTokensTable: verificationTokens,
  }),
  providers: [Google],
  session: {
    // We're using the Drizzle adapter, so sessions are stored in the
    // database rather than encoded as a JWT. That also means the `session`
    // callback below gets the full DB user row for free.
    strategy: "database",
  },
  pages: {
    signIn: "/signin",
  },
  callbacks: {
    session: async ({ session, user }) => {
      session.user.id = user.id;
      session.user.isOwner = user.isOwner;
      return session;
    },
  },
  events: {
    // Runs once, right after the adapter inserts a brand-new user row.
    // If this is the very first user this app has ever seen, make them the
    // Owner. There's no invite flow yet, so this is the whole bootstrap.
    createUser: async ({ user }) => {
      if (!user.id) return;
      await maybeBootstrapOwner(user.id);
    },
  },
});
