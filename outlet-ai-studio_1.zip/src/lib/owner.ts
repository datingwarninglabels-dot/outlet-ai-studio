import { count, eq } from "drizzle-orm";

import { db } from "@/db";
import { users } from "@/db/schema";

/**
 * If `userId` is the only user in the table, promote them to Owner.
 *
 * Called from the Auth.js `createUser` event (see src/auth.ts), which fires
 * once, right after the adapter inserts a brand-new user row — so at that
 * point "only user in the table" means "first person to ever sign in."
 * Pulled out into its own function so it can be exercised directly against
 * a real database in tests, without going through a full OAuth round trip.
 */
export async function maybeBootstrapOwner(userId: string): Promise<boolean> {
  const [{ total }] = await db.select({ total: count() }).from(users);

  if (total !== 1) {
    return false;
  }

  await db.update(users).set({ isOwner: true }).where(eq(users.id, userId));
  return true;
}
